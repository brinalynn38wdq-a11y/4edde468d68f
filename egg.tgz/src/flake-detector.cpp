// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("flake detector"); }
int main(){
  announce();
  return lionss_run_workload("flake-detector");
}
