// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("msan\n", stdout);
  return lionss_run_workload("msan");
}
