# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(dependency-review src/dependency-review.cpp)
set_property(TARGET dependency-review PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-review lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(fortify-source src/fortify-source.cpp)
set_property(TARGET fortify-source PROPERTY CXX_STANDARD 11)
target_link_libraries(fortify-source lionss pthread)

add_executable(structure-aware-fuzz src/structure-aware-fuzz.cpp)
set_property(TARGET structure-aware-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(structure-aware-fuzz lionss pthread)

add_executable(compile-time-report src/compile-time-report.cpp)
set_property(TARGET compile-time-report PROPERTY CXX_STANDARD 11)
target_link_libraries(compile-time-report lionss pthread)

add_executable(iwyu src/iwyu.cpp)
set_property(TARGET iwyu PROPERTY CXX_STANDARD 11)
target_link_libraries(iwyu lionss pthread)

add_executable(jetson-build src/jetson-build.cpp)
set_property(TARGET jetson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jetson-build lionss pthread)

add_executable(unused-includes src/unused-includes.cpp)
set_property(TARGET unused-includes PROPERTY CXX_STANDARD 11)
target_link_libraries(unused-includes lionss pthread)

add_executable(drmemory src/drmemory.cpp)
set_property(TARGET drmemory PROPERTY CXX_STANDARD 11)
target_link_libraries(drmemory lionss pthread)

add_executable(msan src/msan.cpp)
set_property(TARGET msan PROPERTY CXX_STANDARD 11)
target_link_libraries(msan lionss pthread)

add_executable(cmake-presets src/cmake-presets.cpp)
set_property(TARGET cmake-presets PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-presets lionss pthread)

add_executable(feature-flags-matrix src/feature-flags-matrix.cpp)
set_property(TARGET feature-flags-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(feature-flags-matrix lionss pthread)

add_executable(coverage-guided-fuzz src/coverage-guided-fuzz.cpp)
set_property(TARGET coverage-guided-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-guided-fuzz lionss pthread)

add_executable(autosar-check src/autosar-check.cpp)
set_property(TARGET autosar-check PROPERTY CXX_STANDARD 11)
target_link_libraries(autosar-check lionss pthread)

add_executable(sast-scan src/sast-scan.cpp)
set_property(TARGET sast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(sast-scan lionss pthread)

add_executable(clang-16 src/clang-16.cpp)
set_property(TARGET clang-16 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-16 lionss pthread)

add_executable(freebsd-build src/freebsd-build.cpp)
set_property(TARGET freebsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(freebsd-build lionss pthread)

add_executable(source-tarball src/source-tarball.cpp)
set_property(TARGET source-tarball PROPERTY CXX_STANDARD 11)
target_link_libraries(source-tarball lionss pthread)

add_executable(windows-arm64 src/windows-arm64.cpp)
set_property(TARGET windows-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-arm64 lionss pthread)

add_executable(uml-diagrams src/uml-diagrams.cpp)
set_property(TARGET uml-diagrams PROPERTY CXX_STANDARD 11)
target_link_libraries(uml-diagrams lionss pthread)

add_executable(flake-detector src/flake-detector.cpp)
set_property(TARGET flake-detector PROPERTY CXX_STANDARD 11)
target_link_libraries(flake-detector lionss pthread)

add_executable(asan-ubsan src/asan-ubsan.cpp)
set_property(TARGET asan-ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan-ubsan lionss pthread)

add_executable(todo-scan src/todo-scan.cpp)
set_property(TARGET todo-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(todo-scan lionss pthread)

add_executable(illumos-build src/illumos-build.cpp)
set_property(TARGET illumos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(illumos-build lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(api-tests src/api-tests.cpp)
set_property(TARGET api-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(api-tests lionss pthread)

add_executable(reproducible-build src/reproducible-build.cpp)
set_property(TARGET reproducible-build PROPERTY CXX_STANDARD 11)
target_link_libraries(reproducible-build lionss pthread)

add_executable(mutation-testing src/mutation-testing.cpp)
set_property(TARGET mutation-testing PROPERTY CXX_STANDARD 11)
target_link_libraries(mutation-testing lionss pthread)

add_executable(leap-second-tests src/leap-second-tests.cpp)
set_property(TARGET leap-second-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(leap-second-tests lionss pthread)

add_executable(contract-tests src/contract-tests.cpp)
set_property(TARGET contract-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(contract-tests lionss pthread)

